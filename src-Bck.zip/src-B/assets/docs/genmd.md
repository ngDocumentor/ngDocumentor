# Generate .md

* (Substance.io)[http://substance.io/examples/tangle/] - Allows for writing as an doc file
* (Simplemde online Editors)[https://simplemde.com/] - Allows for writing in markdown format and see preview