# CREDITS

* Markdown conversion done using ngx-markdown created by [jcere](https://github.com/jfcere) with repository hosted at [ngx-markdown](https://github.com/jfcere/ngx-markdown)

* Simple total count based search created by [ganeshkbhat](https://github.com/ganeshkbhat) which can be scaled to better versions for very huge document searches

* Site Distribution made using NgDocumentor created by [ganeshkbhat](https://github.com/ganeshkbhat) with repository hosted at [ngDocumentor](https://github.com/ngDocumentor/ngDocumentor)

* Project uses [Angular](https://angular.io/) and [Angular-CLI](https://cli.angular.io/)

